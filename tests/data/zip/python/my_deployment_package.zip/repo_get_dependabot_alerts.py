from dataclasses import dataclass, field
from typing import Any, Dict, Iterator, List, Optional

from mashumaro import field_options
from nest_asyncio import asyncio

from plugins.github.adapter.issues import get_dependabot_issue_input
from plugins.github.io.inbound.types import AlertState

from utils.asyncio import make_sync
from utils.aws.lambda_ import sqs_unpack, typed_lambda

from ...io.outbound.aws.ddb import (
    DependabotAlertsTable,
    PaginationTable,
    get_cursor,
    set_cursor,
    update_ddb_table,
)
from .common import RepoLambdaCommonParameters


INSTANCE_ID = "instance_id"


@dataclass(kw_only=True)
class RepoGetDependabotAlertsParams(RepoLambdaCommonParameters):
    batch_size: int = field(default=50, metadata=field_options(alias="batchSize"))
    states: List[AlertState] = field(default_factory=lambda: ["OPEN"])
    after: Optional[str] = field(default=None)


def _process_data(
    *,
    instance_id: str,
    repo_name: str,
    org_name: str,
    response_data: List[Dict[str, Any]],
) -> Iterator[Dict[str, Any]]:
    for final in response_data:
        final.update(
            {
                INSTANCE_ID: instance_id,
                "repo": repo_name,
                "org": org_name,
                "url": f"https://github.com/{org_name}/{repo_name}/security/dependabot/{final['number']}",
            }
        )
        yield final


@make_sync
@sqs_unpack
@typed_lambda
async def handler(event: RepoGetDependabotAlertsParams, _) -> None:
    github = await event.get_client()
    gqlgo_client = event.get_graphql_client("get_dependabot_alerts")
    resp_has_next_page = True
    max_pages = event.max_pages
    assert not max_pages or max_pages > 0
    repo_id = f"{event.org}/{event.repo}"
    query_id = f"dependabot_alerts-{event.states}-{event.org}-{event.repo}"
    last_cursor = get_cursor(
        PaginationTable,
        instance_id=event.instance_id,
        query_id=query_id,
    )
    after = event.after
    if after is None:
        end_cursor = last_cursor.get("end_cursor")
        after = end_cursor

    counter = 0
    while resp_has_next_page:
        if max_pages and counter > max_pages:
            break
        response = await github.get_dependabot_alerts_paginated(
            repo=repo_id,
            states=event.states,
            first=event.batch_size,
            after=event.after,
        )

        resp_has_next_page = response.page_info.hasNextPage
        after = response.page_info.endCursor
        counter += 1
        await asyncio.gather(
            *[
                gqlgo_client.createIssue(get_dependabot_issue_input(alert, repo_id))
                for alert in response.data
            ]
        )
        update_ddb_table(
            DependabotAlertsTable,
            "DependabotAlerts",
            _process_data(
                instance_id=event.instance_id,
                response_data=response.data,
                repo_name=event.repo,
                org_name=event.org,
            ),
            hash_key=INSTANCE_ID,
            range_key="url",
        )

    set_cursor(
        table=PaginationTable,
        instance_id=event.instance_id,
        query_id=query_id,
        data={"end_cursor": after},
    )
